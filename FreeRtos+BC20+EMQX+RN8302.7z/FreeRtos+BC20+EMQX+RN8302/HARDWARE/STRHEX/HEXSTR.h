//#include "sys.h"
#include "string.h"    


extern char Value2Hex(const int value);
extern int Str2Hex(char *str,char *hex);
