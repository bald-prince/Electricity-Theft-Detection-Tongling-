#ifndef _SPI_H_
#define _SPI_H_

#include <stdio.h>
#include "stm32f10x.h"
#include "config.h"


#endif
